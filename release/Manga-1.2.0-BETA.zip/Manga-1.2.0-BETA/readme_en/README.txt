﻿1) get the url of the manga (eg. http://mangafox.me/manga/log_horizon/)
2) fill url into downloader.txt after "url=" (line 5)
3) run Manga.bat
