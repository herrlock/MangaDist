﻿1) get the url of the manga (eg. http://mangafox.me/manga/log_horizon/)
2) fill url into downloader.txt after "url=" (line 5)
3) run Manga.bat
4) look into the folder "download" the downloaded chapters are located there
    (the numebrs at the end of the name are a timestamp to avoid accidentally overwriting the folder)
