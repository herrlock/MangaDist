﻿1) url des mangas holen (z.b. http://mangafox.me/manga/log_horizon/)
2) url in "downloader.txt" nach "url=" (zeile 5) einfügen
3) Manga.bat ausführen
