# Example scripts

This folder contains example-scripts used for different purposes.
Most scripts need to be run from the application's root-folder, so you should copy or move them.

> You should always try to understand the scripts before running them!
