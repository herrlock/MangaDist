﻿
1) get the url of the manga (eg. http://mangafox.me/manga/log_horizon/)
2) run "Run.bat"
3) fill the fields in the GUI
4) start the desired task

