﻿
1) get the url of the manga (eg. http://mangafox.me/manga/log_horizon/)
2) run Gui.bat (Windows) or Gui (other)
3) fill the fields in the GUI
4) start the desired task

