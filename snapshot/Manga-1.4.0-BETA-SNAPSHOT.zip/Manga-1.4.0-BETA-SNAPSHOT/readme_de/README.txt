﻿
1) URL des Mangas holen (z.b. http://mangafox.me/manga/log_horizon/)
2) Gui.bat (Windows) oder Gui (andere) ausführen
3) in der GUI die benötigten Felder ausführen
4) die gewünschte Aufgabe ausführen 

