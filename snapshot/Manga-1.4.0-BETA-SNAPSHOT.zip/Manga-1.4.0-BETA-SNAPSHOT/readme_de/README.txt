﻿1) URL des Mangas holen (z.b. http://mangafox.me/manga/log_horizon/)
2) URL in "downloader.txt" nach "url=" (zeile 5) einfügen
3) Manga.bat ausführen
4) In den Ordner "download" schauen, dort befinden sich die heruntergeladenen Kapitel 
    (die Ziffen am Ende dienen dazu, dass der Ordner nicht versehenlich überschrieben wird)
