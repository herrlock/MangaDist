﻿
1) URL des Mangas holen (z.b. http://mangafox.me/manga/log_horizon/)
2) "Run.bat" ausführen
3) in der GUI die benötigten Felder ausfüllen
4) die gewünschte Aufgabe ausführen 

