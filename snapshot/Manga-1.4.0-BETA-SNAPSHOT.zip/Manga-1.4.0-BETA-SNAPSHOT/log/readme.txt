
EN: 
This folder's purpose is to contain the log-files from executing the application.
A file inside here can be deleted without affecting the application's behaviour.

DE: 
Der Sinn dieses Ordners ist es die Logdateien zu enthalten, die bei der Ausführung der Applikation entstehen.
Eine Datei hier kann ohne Beeinflussung der Applikation gelöscht werden.
